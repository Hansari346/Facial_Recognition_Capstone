from distutils.core import setup

setup(name='ImageEncryptor',
      version='0.1',
      description='Image Encryption',
      author='James Lucas',
      packages=['ImageEncryptor'],
     )
