# Importing the libraries
import cv2  # for image reading
import pandas as pd  # for data frames management
import os  # for opening directories
import warnings  # to hide some useless warnings


warnings.filterwarnings("ignore", category=FutureWarning)  # ignore all FutureWarnings that may appear

mainPath = "123/Student_Pictures"  # define the pictures directory
STUDENTS = sorted(os.listdir(mainPath))  # extract the list of students existing in the main directory

# defining empty data frames to store images and labels
faces_train_img = pd.DataFrame([])  # for training images
faces_train_lbl = pd.DataFrame([])  # for training labels
faces_test_img = pd.DataFrame([])  # for testing images
faces_test_lbl = pd.DataFrame([])  # for testing images


for student in STUDENTS:  # for each student folder found in the main directory
    currentPath = mainPath + "/" + student + "/sharp_Train/"  # define the sharp_train directory
    img_path_list = sorted(os.listdir(currentPath))  # extract all images name in the sharp_train directory
    for img_path in img_path_list:  # for each image from the list
        img = cv2.imread(currentPath + img_path)  # , cv2.IMREAD_GRAYSCALE)  # read the image

        face_img = pd.Series(img.flatten(), name=currentPath + img_path)  # flatten this image
        faces_train_img = faces_train_img.append(face_img)  # add the flat image as a row in the data frame

        face_lbl = pd.Series(student, name=currentPath + img_path)  # add the name of the student
        faces_train_lbl = faces_train_lbl.append(face_lbl)  # to the label data frame


for student in STUDENTS:  # for each student folder found in the main directory
    currentPath = mainPath + "/" + student + "/sharp_Test/"  # define the sharp_test directory
    img_path_list = sorted(os.listdir(currentPath))  # extract all images name in the sharp_test directory
    for img_path in img_path_list:  # for each image from the list
        img = cv2.imread(currentPath + img_path)  # , cv2.IMREAD_GRAYSCALE)  # read the image

        face_img = pd.Series(img.flatten(), name=currentPath + img_path)  # flatten this image
        faces_test_img = faces_test_img.append(face_img)  # add the flat image as a row in the data frame

        face_lbl = pd.Series(student, name=currentPath + img_path)  # add the name of the student
        faces_test_lbl = faces_test_lbl.append(face_lbl)  # to the label data frame


train_img = faces_train_img.loc[:, :].values  # define a new matrix that has only the values of the train data
train_lbl = faces_train_lbl.loc[:, :].values.ravel()  # define a new list labels of the train data

test_img = faces_test_img.loc[:, :].values  # define a new matrix that has only the values of the test data
test_lbl = faces_test_lbl.loc[:, :].values.ravel()  # define a new list labels of the test data

# importing the preprocessing class
from sklearn.preprocessing import StandardScaler

# instantiate a standardScaler
scaler = StandardScaler()
# Fit on training set only
scaler.fit(train_img)
# Apply transform to both the training set and the test set
train_img = scaler.transform(train_img)
test_img = scaler.transform(test_img)

# importing the PCA class
from sklearn.decomposition import PCA
# Make an instance of the Model
pca = PCA(.95)
# Fit on training set only
pca.fit(train_img)
# Apply transform to both the training set and the test set
train_img = pca.transform(train_img)
test_img = pca.transform(test_img)

# importing the logisticRegression class
from sklearn.linear_model import LogisticRegression
# Make an instance of the Model
logisticRegr = LogisticRegression(solver='lbfgs', max_iter=10000)
# Fit on training set only (for each image, giving a label)
logisticRegr.fit(train_img, train_lbl)

# define a testing list
test_labels = [0, 35, 69, 120, 220]

for i in test_labels:  # for each test element of the list
    print('Prediction : ', logisticRegr.predict(test_img[i].reshape(1, -1)))  # print the prediction
    print('Correct name : ', test_lbl[i])  # print the right name of the student in the image
    print('_________________________')  # to separate results

print('Accuracy : ', int(logisticRegr.score(test_img, test_lbl)*100))  # and finaly calculate and print the accuracy
# of the PCA method

# you can uncomment the conversion to gray scale part to see that the accuracy will diminish




