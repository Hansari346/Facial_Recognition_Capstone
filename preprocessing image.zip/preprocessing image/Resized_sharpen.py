import cv2
import os
import numpy as np


mainPath = "/Users/yasse/Desktop/Student_Pictures"

# this is the entire list of students we have so far
STUDENTS = sorted(os.listdir(mainPath))

# width of resized images
width = 100
# height of resized images
height = 120
# define the kernel
kernel = np.array([[0, -1, 0],
                   [-1, 5, -1],
                   [0, -1, 0]])


# for each student in the list
for student in STUDENTS:
    print('Processing ' + student + ' folder...')
    # this is a list of strings: Anchor, Extras, Test, Train
    SUBCATEGORY = sorted(os.listdir(mainPath + "/" + student))

    # for each subdirectory in each student's directory
    for category in SUBCATEGORY:
        # create the total current path
        if category == 'Train' or category == 'Test':
            currentPath = mainPath + "/" + student + "/" + category

            # create the total desired path
            gotoPath_resize = mainPath + "/" + student + "/resize_" + category
            gotoPath_sharp = mainPath + "/" + student + "/sharp_" + category

            # create a new directory with the name of the category + resize
            os.mkdir(gotoPath_resize)
            os.mkdir(gotoPath_sharp)

            # for each image in each subdirectory in each student's directory
            for img in os.listdir(currentPath):
                # read in the image
                image = cv2.imread(currentPath + "/" + img)
                # resize the image
                resized_image = cv2.resize(image, (width, height))
                # Sharpen image
                sharp_image = cv2.filter2D(resized_image, -1, kernel)
                # save the image to the desired path
                cv2.imwrite(gotoPath_resize + "/" + img, resized_image)
                # save the image to the desired path
                cv2.imwrite(gotoPath_sharp + "/" + img, sharp_image)

print('Done.')
