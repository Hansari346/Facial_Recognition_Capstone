import cv2
import os
import numpy as np
import os
import cv2

mainPath = "/Users/yasse/Desktop/Student_Pictures_100x120"
desiredPath = "/Users/yasse/Desktop/Student_Pictures_sharpened1" #CHANGE THIS DIRECTORY NAME EVERY TIME

#this is the entire list of students we have so far
STUDENTS = sorted(os.listdir(mainPath))
#this is a list of strings: Anchor, Extras, Test, Train
SUBCATEGORY = sorted(os.listdir(mainPath+"/"+STUDENTS[0]))
#width of resized images
width = 100
#height of resized images
height = 120


kernel = np.array([[1/16, 1/8, 1/16],
                   [1/8, 1/4, 1/8],
                   [1/16, 1/8, 1/16]])

#make a directory: os.mkdir(path)

os.mkdir(desiredPath)

for student in STUDENTS:
    os.mkdir(desiredPath+"/"+student)
    for category in SUBCATEGORY:
        os.mkdir(desiredPath+"/"+student+"/"+category)
        

#for each student in the list
for student in STUDENTS:
    #for each subdirectory in each student's directory
    for category in SUBCATEGORY:
        #create the total current path
        currentPath = mainPath + "/" + student + "/" + category
        #create the total desired path
        gotoPath = desiredPath + "/" + student + "/" + category
        #for each image in each subdirectory in each student's directory
        for img in os.listdir(currentPath):
            #read in the image
            image = cv2.imread(currentPath+ "/" + img)
            #resize the image
            #resized_image = cv2.resize(image,(width,height))
            # Sharpen image
            sharp_image = cv2.filter2D(image, -1, kernel)
            
            #save the image to the desired path
            cv2.imwrite(gotoPath + "/" + img, sharp_image)


